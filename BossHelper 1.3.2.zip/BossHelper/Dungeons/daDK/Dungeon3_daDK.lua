Dungeon3 = {
    displayName = "Nexus-Point Xenas",
    realName    = "Nexus-Point Xenas",
    bosses = {
        {
            realName    = "Chief CorewrightKasreth",
            displayName = "Kasreth",
            short       = [[
1. Avoid beams & kick boss.
2. When you get the Reflux Charge debuff, move INTO the beams to remove it (ideally move into overlaping beams).
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Corewarden Nysarra",
            displayName = "Corewarden Nysarra",
            short       = [[
1. Move out with circle.
2. Kick and nuke adds.
3. When yellow guy appears, do NOT stand between him and the boss. AFTER he stuns the boss, move into yellow ray.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Lothraxion",
            displayName = "Lothraxion",
            short       = [[
1. Move out with circles, and don't stand in the giant arrows of doom.
2. After the attack at 100 energy, the boss clones itself. Only interrupt the clone WITHOUT horns.
]],
            details     = [[Comming soon
]]
        },
    }
}

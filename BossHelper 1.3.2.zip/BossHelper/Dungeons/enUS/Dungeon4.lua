Dungeon4 = {
    displayName = "Windrunner Spire",
    realName    = "Windrunner Spire",
    bosses = {
        {
            realName    = "Derelict Duo",
            displayName = "Derelict Duo",
            short       = [[
1. Interrupt boss, and move out with circles.
2. CC adds (or curse dispel to despawn)
3. When targeted by hookshot, move behind spooky ghost lady.

Tank Move boss when ground gets too cluttered.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Emberdawn",
            displayName = "Emberdawn",
            short       = [[
1. Fire = bad
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Commander Kroluk",
            displayName = "Commander Kroluk",
            short       = [[
1. Brown circles = bad.
2. Overlap purple circles.
3. Run when fixated.
4. When adds spawn, prio nuke Mystic.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "The Restless Heart",
            displayName = "Restless Heart",
            short       = [[
1. Step on small windy arrows to remove Squall Leap DoT AND to jump over expanding shockwave.
2. Move out of frontal if not targeted.
3. Use big circles to clear electric stuff off the ground.
]],
            details     = [[Comming soon
]]
        },
    }
}

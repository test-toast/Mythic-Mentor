Dungeon1 = {
    displayName = "Maisara Caverns",
    realName    = "Maisara Caverns",
    bosses = {
        {
            realName    = "Muro'jin and Nekraxx",
            displayName = "Muro'jin and Nekraxx",
            short       = [[
1. Ice traps, green circles & frontal barrage = bad.
2. If targeted by Carrion Swoop, move INTO an ice trap.
]],
            details     = [[Comming soon
]]
        },












        
        {
            realName    = "Vordaza",
            displayName = "Vordaza",
            short       = [[
1. Boss spawns 4 phantoms fixating the tank & the DPS. Overlap phantoms to despawn them - but stagger this!.
2. Avoid rotating frontal beam, and floating orbs.

Healer. Phantoms despawning = big group damage.
]],
            details     = [[Comming soon
]]
        },








        




        
        {
            realName    = "Rak'tul, Vessel of Souls",
            displayName = "Rak'tul",
            short       = [[
1. Boss leaps to 3 players & leaves totems behind. Don't get crushed, and destroy totems asap.
2. During soul phase, CC & kick big adds as you run to boss.

Tank. Place puddles away from group.
]],
            details     = [[Comming soon
]]
        },
    }
}

-- Table of English strings
-- Translate("ANIMATIONS_TOOLTIP")
L_enUS = {
    -----------------------------------------------
    -- UI Labels
    -----------------------------------------------
    ["DUNGEONS"] = "Dungeons",
    ["GENERAL"] = "General",
    ["BACK"] = "Back",
    ["POST_TO_CHAT"] = "Post to chat",
    ["COMING_SOON"] = "Coming soon",
    ["HIDE_DETAILS"] = "Hide Details",
    ["SHOW_DETAILS"] = "Show Details",
    ["THIS_WEEK_AFFIXES"] = "This Week's Affixes",


    -----------------------------------------------
    -- settings
    -----------------------------------------------
    ["SETTINGS"] = "Settings",

    -- category names
    ["GENERAL_CATE"] = "General",
    ["AUTO_INVITE_CATE"] = "Auto-Invite",

    -- text
    ["/RELOAD_TEXT"] = "Tactics updated. Use /reload for UI translation.",

    -- Setting Main
    ["SELECT_LANGUAGE_TITLE"] = "Select Language",
    ["SCALE_SLIDER_TITLE"] = "Addon Scale",
    ["ANIMATIONS_COMBT_TITLE"] = "Allow animations in combat",
    ["CLOSE_WINDOW_TITLE"] = "Close window on Post",
    ["ESC_CLOSE_TITLE"] = "Allow closing with ESC",
    ["AUTO_OPEN_NOTES_TITLE"] = "Auto-open Boss Notes",

    ["AUTO_INVITE_TITLE"] = "Enable Auto-Invite",
    ["TRIGGER_WORD_TITLE"] = "AutoInvite Trigger Word",

    -- ToolTip settings
    ["LANGUAGE_TOOLTIP_1"] = "Choose the language used in Mythic Menter.",
    ["LANGUAGE_TOOLTIP_2"] = "Click to open the list of available languages.",
    ["SCALE_TOOLTIP"] = "Changes the scale of the entire addon. Drag to change.",
    ["CURRENT_SCALE_TOOLTIP"] = "Current: ",
    ["ANIMATIONS_TOOLTIP"] = "Play animations in combat.",
    ["CLOSE_WINDOW_TOOLTIP"] = "Close window after 'Post to chat' is pressed.",
    ["ESC_CLOSE_TOOLTIP"] = "Close window with ESC.",
    ["AUTO_OPEN_NOTES_TOOLTIP"] = "Automatically open the Boss Notes panel\nwhen selecting a boss (if notes exist).",

    ["AUTO_INVITE_TOOLTIP"] = "Enable Auto-Invite (invites on trigger).",
    ["TRIGGER_WORD_TOOLTIP"] = "Trigger word for Auto-Invite (e.g. invite!).",

    -----------------------------------------------
    -- Start Side
    -----------------------------------------------

    -- Text
    ["SELECT_DUNGEON_HINT"] = "Select a dungeon in the left panel to view bosses and tactics.",

    -----------------------------------------------
    -- Notes
    -----------------------------------------------

    -- Boss Notes
    ["BOSS_NOTES"] = "Boss Notes",
    ["BOSS_CLOSE_NOTE"] = "Close Note",
    ["ADD_NOTE_TIP"] = "Write note and press Enter:",

    -- General Notes
    ["GENERAL_NOTES"] = "General Notes",
    ["ADD_CATEGORY"] = "New Category",
    ["DEFAULT_CATEGORY"] = "All",
    ["CONFIRM_DELETE_NOTE"] = "Are you sure you want to delete this note?",
    ["CONFIRM_DELETE_CATEGORY"] = "Are you sure you want to delete this category and all its notes?",


    -----------------------------------------------
    -- Info panel
    -----------------------------------------------

    ["INFO"] = "Information",


    -----------------------------------------------
    -- Socials
    -----------------------------------------------
    ["DISCORD_TOOLTIP"] = "Click to get the Discord link.",
    ["JOIN_DISCORD"] = "Join Our Discord!",

    ["GITHUB_TOOLTIP"] = "Click to get the GitHub link.",
    ["VISIT_GITHUB"] = "Visit Our GitHub!",

    ["BUG_TOOLTIP"] = "Click to report a bug",
    ["REPORT_BUG"] = "Report a Bug!",
    ["BUG_GUIDE"] = "Found a bug? Report it via Discord or GitHub Issues.",


    ["COPY_LINK"] = "Ctrl+C to copy link",

    -----------------------------------------------
    -- Update banner
    -----------------------------------------------
    ["UPDATE_AVAILABLE_BANNER"] = "New update available – Yours: %s  New: %s  (click to open)",
}

return L_enUS
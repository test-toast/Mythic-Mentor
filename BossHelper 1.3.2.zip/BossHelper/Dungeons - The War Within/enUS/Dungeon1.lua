Dungeon1 = {
    displayName = "Eco-Dome Al'dani",
    realName    = "Eco-Dome Al'dani",
    bosses = {
        {
            realName    = "Azhiccar",
            displayName = "Azhiccar",
            short       = [[
1. Focus down adds.
2. Move out with circles.
3. Don't let the boss suck in any player or add.
]],
            details     = [[

{center}|cFFFF6600AZHICCAR - DETAILED STRATEGY|r{/center}

This fight alternates between a |cFF00FFFFboss phase|r and an |cFF00FFFFadd phase|r. 
During the boss phase, tank must stay in range of the stationary boss to prevent [Miscellaneous:Thrash] from triggering.

__________________________________________________________________________

{center}|cFFFF6600Invading Shriek|r{/center}

Twice per boss phase, Azhiccar will cast [BossAbilities:Invading Shriek], dealing group-wide damage and spawning [BossAbilities:Frenzied Mites] from fixed locations around the room.
These [BossAbilities:Mites]:
- Randomly attack players.
- Gain a stacking [Miscellaneous:10% damage] increase|r each time they use [BossAbilities:Engorge].
- Must be defeated quickly before they grow too powerful.

|cFFFFFF00Strategy:|r
Keep the group stacked together to bait all the [BossAbilities:Mites] to one spot, then use AoE stuns and slows to control them while cleaving them down.

__________________________________________________________________________

{center}|cFFFF6600Toxic Regurgitation|r{/center}

The boss will also target 2 players with [BossAbilities:Toxic Regurgitation], applying a shadow DoT in an AoE around them and creating a [BossAbilities:Digestive Spittle puddle] at their location.

|cFFFFFF00Positioning:|r
- Drop [BossAbilities:puddles] near the edge of the arena to maximize space during add phases.
- Placing [BossAbilities:puddles] on add spawn points will slow the [BossAbilities:Mites], making the
  [BossAbilities:Devour phase] much easier BUT will make it harder for melee players to reach the 
  [BossAbilities:Mites].

__________________________________________________________________________

{center}|cFFFF6600Devour and feast|r{/center}

When Azhiccar reaches [Miscellaneous:100 energy], he channels [BossAbilities:Devour] for 18 seconds:
- Deals ticking shadow damage to the group.
- Pulls players toward him, anyone too close will be instantly killed.
- Spawns [BossAbilities:Frenzied Mites]. They're divided into two groups of 3 each, ignoring 
  players and moving directly toward Azhiccar.

If any player or Mite reaches the boss:
- Azhiccar casts [Debuff:Feast], healing himself and gaining a stacking damage buff for 90 
  seconds.

|cFFFFFF00Strategy for Devour:|r
- Use slows, knockbacks, and hard CC to keep the [BossAbilities:Mites] away from the boss.
- Kill all 6 [BossAbilities:Mites] before the channel ends, or Azhiccar will [Debuff:Feast] on any
    remaining ones.
- Use personal movement cooldowns to escape the pull and survive.

__________________________________________________________________________

After [BossAbilities:Devour] finishes:
- All Digestive Spittle [BossAbilities:puddles] disappear.
- The fight resets back into the boss phase.
- During this time, tank are free to help DPS the [BossAbilities:Mites] since Azhiccar will not melee or cast [Miscellaneous:Thrash].

__________________________________________________________________________

|cFFFFFF00Summary Flow:|r
1. Handle Toxic Regurgitation by placing puddles at the edges or on the add
    spawn points.
2. Focus down all [BossAbilities:Frenzied Mites] immediately.
3. Prepare for [BossAbilities:Devour] at [Miscellaneous:~90 energy].
4. Control and kill [BossAbilities:Devour] [BossAbilities:Mites] while running away from the pull.
5. Repeat until Azhiccar is defeated.
]]
        },












        
        {
            realName    = "Taah'bat and A'wazj",
            displayName = "Taah'bat and A'wazj",
            short       = [[
1. Move out with circles & destroy the javelins asap.
2. Once Taah'bat dismounts, point the Warp Strikes through him to break the shield. 6 hits are needed.
]],
            details     = [[

{center}|cFFFF6600TAAH'BAT AND A'WAZJ - DETAILED STRATEGY|r{/center}

This encounter begins with |cFF00FFFFA'wazj|r as the active boss, while |cFF00FFFFTaah'bat|r rides unattackable on their back.  

__________________________________________________________________________

{center}|cFFFF6600Binding Javelins|r{/center}

During this phase, Taah'bat will target 2 random players with [BossAbilities:Binding Javelin] / [BossAbilities:circles], creating an 8yd AoE around them and binding anyone hit to the spears.  

|cFFFFFF00Strategy:|r
- Stand close together with [BossAbilities:circles] but avoid standing inside each other's [BossAbilities:circles].
- Drag Boss between the [BossAbilities:circles] once they land to maximize cleave and free tethered players ASAP.
- Breaking these tethers quickly is critical to prevent heavy damage.

__________________________________________________________________________

{center}|cFFFF6600Warp Strike|r{/center}

Shortly after [BossAbilities:Binding Javelin], A'wazj casts [BossAbilities:Warp Strike] on a random player:
- Dashes after a short delay.
- Applies a [Debuff:stacking DoT] to anyone in its path.  

|cFFFFFF00Tips:|r
- Avoid getting hit while tethered.
- Use defensive cooldowns if targeted while tethered.
- Keep moving and avoid overlap with other players.

__________________________________________________________________________

{center}|cFFFF6600Rift Claws|r{/center}

Tank should use a cooldown on every cast of [Debuff:Rift Claws]:
- Deals a large arcane hit in an arc.
- Applies a small bleed.

__________________________________________________________________________

{center}|cFFFF6600Arcane Blitz (Taah'bat Dismount)|r{/center}

When A'wazj reaches [Miscellaneous:100 energy], |cFF00FFFFTaah'bat|r dismounts and becomes unattackable:
- A'wazj repeatedly casts [BossAbilities:Warp Strike].
- Taah'bat casts [BossAbilities:Arcane Overload], dealing constant ticking damage.
- Taah'bat gains [Miscellaneous:Incorporeal] buff, making him immune to damage.

|cFFFFFF00Removing Incorporeal:|r
- Targeted players must move [BossAbilities:Warp Strike] through Taah'bat [Important:6 times] to remove the buff.
- Avoid stacking the DoT multiple times; use defensives if necessary.

__________________________________________________________________________

Once all 6 stacks of Incorporeal are broken:
- Both bosses are [Debuff:Destabilized] for 15s.
- [Important:Cleave them together] for bonus damage thanks to them sharing health from the Beastmaster's Bond passive.
- After 15s, Taah'bat remounts A'wazj and Repeat.

__________________________________________________________________________

|cFFFFFF00Summary Flow:|r
1. Handle [BossAbilities:Binding Javelins] quickly; overlap [BossAbilities:circles] and drag Boss between them.
2. Watch out for [BossAbilities:Warp Strike] and [Debuff:stacking DoTs]; use defensives when necessary.
3. Tank use cooldowns on [Debuff:Rift Claws].
4. When Taah'bat dismounts, targeted players hit him [Important:6 times] with [BossAbilities:Warp Strike] to remove [Miscellaneous:Incorporeal].
5. Cleave both bosses during [Debuff:Destabilized] for bonus damage.
6. Repeat until both bosses are defeated.
]]
        },








        




        
        {
            realName    = "Soul-Scribe",
            displayName = "Soul-Scribe",
            short       = [[
1. Run over your soul fragment.
2. Move out with circles.
3. At full energy, 3 Echos/soul fragments spawn. Run over all of them starting with the one in imminent danger.
]],
            details     = [[

{center}|cFFFF6600SOUL-SCRIBE - DETAILED STRATEGY|r{/center}

Throughout this encounter, the boss uses [BossAbilities:Whispers of Fate]
- Damages all players.
- Shatters an [Important:Echo/soul fragment] of each player somewhere in the room.

|cFFFFFF00Collecting|r [Important:Echo/soul fragments]
- Players can run over their own [Important:Echo/soul fragment] to gain the stacking
  [Buff:Fatebound] buff.
- If a boss ability hits the [Important:Echo/soul fragment] before collection, the player gets
  [Debuff:Wounded Fate] debuff.

__________________________________________________________________________

{center}|cFFFF6600Ceremonial Dagger|r{/center}

- Fires a line attack targeting [Important:all 5] [Important:Echo/soul fragment], delayed by 5s.
- Identify your [Important:Echo/soul fragment] and grab it before the cast finishes, or you will
  get [Debuff:Wounded Fate] Debuff.

__________________________________________________________________________

{center}|cFFFF6600Dread of the Unknown|r{/center}

- Creates a 9yd AoE around all 5 players that explodes after 4s.
- Players must quickly run to their [Important:Echo/soul fragment] and then spread out to
  avoid cleaving allies.

__________________________________________________________________________

{center}|cFFFF6600Eternal Weave (Ultimate)|r{/center}

At [Miscellaneous:100 energy], Soul-Scribe casts [BossAbilities:Eternal Weave]:
- Spawns 3 [Important:Echo/soul fragments] for each player.
- Fires cones of arcane energy rotating clockwise every 6s for 24s.

Strategy:
- For optimal [Buff:Fatebound] stacking, wait until a frontal is aimed at your
  [Important:Echo/soul fragments] before picking it up.
- or for safety, grab all 3 [Important:Echo/soul fragments] as soon as possible.

__________________________________________________________________________

{center}|cFFFF6600Echoes of Fate|r{/center}
                                                        
On top of these abilities, the boss also deals constant damage to the group throughout the fight with the [BossAbilities:Echoes of Fate] passive.
- Keep moving and be aware of your [Important:Echo/soul fragment] positions
  to minimize damage.

__________________________________________________________________________

Summary Flow:
1. Run over your personal [Important:Echo/soul fragments] immediately after it spawns, but avoid [Debuff:Wounded Fate].
2. Avoid [BossAbilities:Ceremonial Dagger] by identifying your [Important:Echo/soul fragment] and moving in time.
3. Avoid [BossAbilities:Dread of the Unknown] AoEs; spread out after picking up your [Important:Echo/soul fragment].
4. During [BossAbilities:Eternal Weave], collect all 3 [Important:Echo/soul fragments] while dodging rotating arcane cones.
5. Maintain awareness of passive [BossAbilities:Echoes of Fate] damage.
6. Repeat this cycle until Soul-Scribe is defeated.
]]
        },
    }
}

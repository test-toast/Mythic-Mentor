Dungeon7 = {
    displayName = "Seat of the Triumvirate",
    realName    = "Seat of the Triumvirate",
    bosses = {
        {
            realName    = "Zuraal the Ascended",
            displayName = "Zuraal the Ascended",
            short       = [[
1. Avoid frontal.
2. Move out with circle.
3. Kill adds ASAP.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Saprish",
            displayName = "Saprish",
            short       = [[
1. Clear void bombs with circles.
2. Interrupt the Shadewing pet.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Viceroy Nezhar",
            displayName = "Viceroy Nezhar",
            short       = [[
1. Kick Mind Blast, and nuke tentacle adds ASAP.
2. At 100 energy, stack on boss.
]],
            details     = [[Comming soon
]]
        },
        
        {
            realName    = "L'ura",
            displayName = "L'ura",
            short       = [[
1. Point Discordant Beam at the notes around the them.
2. the rotating beams of evil.
3. Avoid big circle explosions.
]],
            details     = [[Comming soon
]]
        },
    }
    
}

-- Table of Danish strings
-- Translate("ANIMATIONS_TOOLTIP")
L_daDK = {
    -----------------------------------------------
    -- UI Labels
    -----------------------------------------------
    ["DUNGEONS"] = "Dungeons",
    ["GENERAL"] = "General",
    ["BACK"] = "Tilbage",
    ["POST_TO_CHAT"] = "Send til chat",
    ["COPY_TEXT"] = "Kopiér tekst",
    ["COMING_SOON"] = "Kommer snart",
    ["HIDE_DETAILS"] = "Skjul detaljer",
    ["SHOW_DETAILS"] = "Vis detaljer",
    ["THIS_WEEK_AFFIXES"] = "Ugens Affixes",
    ["AFFIXES"] = "Affixes",
    ["AFFIXES_LOADING"] = "Affixes ikke tilgængelige endnu. Prøv igen snart.",


    -----------------------------------------------
    -- settings
    -----------------------------------------------
    ["SETTINGS"] = "Indstillinger",

    -- category names
    ["GENERAL_CATE"] = "Generelt",
    ["AUTO_INVITE_CATE"] = "Auto-inviter",

    -- text
    ["/RELOAD_TEXT"] = "Taktikker opdateret. Brug /reload for UI oversættelse.",

    -- Setting Main
    ["SELECT_LANGUAGE_TITLE"] = "Vælg sprog",
    ["SCALE_SLIDER_TITLE"] = "Addon Skala",
    ["ANIMATIONS_COMBT_TITLE"] = "Tillad animationer i kamp",
    ["CLOSE_WINDOW_TITLE"] = "Luk vindue efter post",
    ["ESC_CLOSE_TITLE"] = "Tillad luk med ESC",
    ["AUTO_OPEN_NOTES_TITLE"] = "Åbn Boss Noter automatisk",

    ["AUTO_INVITE_TITLE"] = "Aktiver Auto-Invite",
    ["TRIGGER_WORD_TITLE"] = "AutoInvite Trigger-ord",

    -- ToolTip settings
    ["LANGUAGE_TOOLTIP_1"] = "Vælg sproget brugt i Mythic Mentor.",
    ["LANGUAGE_TOOLTIP_2"] = "Klik for at åbne listen over tilgængelige sprog.",
    ["SCALE_TOOLTIP"] = "Ændrer størrelsen på hele addonet. Træk for at ændre.",
    ["CURRENT_SCALE_TOOLTIP"] = "Nuværende: ",
    ["ANIMATIONS_TOOLTIP"] = "Afspil animationer i kamp.",
    ["CLOSE_WINDOW_TOOLTIP"] = "Luk vinduet efter 'Send til chat' er trykket.",
    ["ESC_CLOSE_TOOLTIP"] = "Luk vindue med ESC.",
    ["AUTO_OPEN_NOTES_TOOLTIP"] = "Åbn Boss Note panelet automatisk\nnår en boss vælges (hvis der findes noter).",

    ["AUTO_INVITE_TOOLTIP"] = "Aktiver Auto-Invite (inviter ved trigger).",
    ["TRIGGER_WORD_TOOLTIP"] = "Trigger-ord for Auto-Invite (f.eks. invite!).",


    -----------------------------------------------
    -- Start Side
    -----------------------------------------------

    -- Text
    ["SELECT_DUNGEON_HINT"] = "Vælg en dungeon i venstre panel for at se bosser og taktikker.",

    -----------------------------------------------
    -- Notes
    -----------------------------------------------

    -- Boss Notes
    ["BOSS_NOTES"] = "Boss Noter",
    ["BOSS_CLOSE_NOTE"] = "Luk note",
    ["ADD_NOTE_TIP"] = "Skriv note og tryk Enter:",

    -- General Notes
    ["GENERAL_NOTES"] = "Generelle noter",
    ["ADD_CATEGORY"] = "Ny kategori",
    ["DEFAULT_CATEGORY"] = "Alle",
    ["CONFIRM_DELETE_NOTE"] = "Er du sikker på, at du vil slette denne note?",
    ["CONFIRM_DELETE_CATEGORY"] = "Er du sikker på, at du vil slette denne kategori og alle dens noter?",
    ["CONFIRM_DELETE_NOTE_TITLE"] = "Slet note",
    ["CONFIRM_DELETE_CATEGORY_TITLE"] = "Slet kategori",


    -----------------------------------------------
    -- Info panel
    -----------------------------------------------

    ["INFO"] = "Information",


    -----------------------------------------------
    -- Socials
    -----------------------------------------------
    ["DISCORD_TOOLTIP"] = "Klik for at få Discord linket.",
    ["JOIN_DISCORD"] = "Deltag i vores Discord!",

    ["GITHUB_TOOLTIP"] = "Klik for at få GitHub linket.",
    ["VISIT_GITHUB"] = "Besøg vores GitHub!",

    ["BUG_TOOLTIP"] = "Klik for at rapportere en fejl.",
    ["REPORT_BUG"] = "Rapportér en fejl!",
    ["BUG_GUIDE"] = "Har du fundet en fejl? Rapportér den via Discord eller GitHub Issues.",

    ["COPY_LINK"] = "Ctrl+C for at kopiere linket.",
    ["COPY_HINT_TEXT"] = "— lukker vinduet",
    ["UNKNOWN_BOSS"] = "Ukendt boss",
    ["TITAN_LEFT_CLICK"] = "Venstreklik: Åbn Mythic Mentor",
    ["TITAN_RIGHT_CLICK"] = "Højreklik: Åbn menu",

    -----------------------------------------------
    -- Update banner
    -----------------------------------------------
    ["UPDATE_AVAILABLE_BANNER"] = "Ny opdatering tilgængelig – Din: %s  Ny: %s  (klik for at åbne)",

    -----------------------------------------------
    -- Edit Tactics
    -----------------------------------------------
    ["TACTIC_PLACEHOLDER"] = "Skriv taktik her...",
    ["DELETE"] = "Slet",
    ["SAVE"] = "Gem",
    ["RESET"] = "Nulstil",
    ["CANCEL"] = "Annuller",
    ["EDIT_TACTICS_TOOLTIP"] = "Rediger taktik",
    ["EDIT_TACTICS_BETA_TITLE"] = "Edit Tactics - Beta",
    ["EDIT_TACTICS_BETA_MSG"] = "Redigering af boss-taktikker er en ny funktion.\n\nDer kan forekomme bugs. Hvis du finder problemer, bedes du rapportere dem på vores Discord eller GitHub.\n\nVil du fortsætte?",
    ["FILTER_PHASE_TOOLTIP"] = "Filter fase",
    ["DELETE_PHASE_TITLE"] = "Slet fase",
    ["DELETE_PHASE_MSG"] = "Er du sikker på, at du vil slette fasen '%s' og alle dens taktikker?\n\nDette kan ikke fortrydes.",
    ["ADD_TACTIC_BTN"] = "+ Tilføj taktik",
    ["RESET_TACTICS_TITLE"] = "Nulstil taktikker",
    ["RESET_TACTICS_MSG"] = "Er du sikker på, at du vil nulstille alle taktikker for denne boss?\n\nDette kan ikke fortrydes.",
    ["UNSAVED_CHANGES_TITLE"] = "Ugemte ændringer",
    ["UNSAVED_CHANGES_MSG"] = "Du har ugemte ændringer.\n\nEr du sikker på, at du vil annullere uden at gemme?",
}

return L_daDK

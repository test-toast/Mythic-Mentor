Dungeon6 = {
    displayName = "Pit of Saron",
    realName    = "Pit of Saron",
    bosses = {
        {
            realName    = "Forgemaster Garfrost",
            displayName = "Forgemaster Garfrost",
            short       = [[
1. Hide behind Saronite Ores during Glacial Overload.

Healer. Dispel debuffs ASAP.
Tank. Move next to a Saronite Ore when he casts Cryostomp.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Ick and Krick",
            displayName = "Ick & Krick",
            short       = [[
1. Prio kick Krick's Death Bolt.
2. Interrupt & kill adds.
3. Run when fixated.

Tank. Avoid placing Blight Smash puddles on purple swirlies.
]],
            details     = [[Comming soon
]]
        },

        {
            realName    = "Scourgelord Tyrannus",
            displayName = "Scourgelord Tyrannus",
            short       = [[
1. Move with blue circles on top of green glowing corpse piles.
2. Kick & kill adds.

Tank. Move to glowing corpse pile during Army of the Dead cast.
]],
            details     = [[Comming soon
]]
        },
    }
    
}

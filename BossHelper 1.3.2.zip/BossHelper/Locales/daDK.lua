-- Table of Danish strings
-- Translate("ANIMATIONS_TOOLTIP")
L_daDK = {
    -----------------------------------------------
    -- UI Labels
    -----------------------------------------------
    ["DUNGEONS"] = "Dungeons",
    ["GENERAL"] = "General",
    ["BACK"] = "Tilbage",
    ["POST_TO_CHAT"] = "Send til chat",
    ["COMING_SOON"] = "Kommer snart",
    ["HIDE_DETAILS"] = "Skjul detaljer",
    ["SHOW_DETAILS"] = "Vis detaljer",


    -----------------------------------------------
    -- settings
    -----------------------------------------------
    ["SETTINGS"] = "Indstillinger",

    -- category names
    ["GENERAL_CATE"] = "Generelt",
    ["AUTO_INVITE_CATE"] = "Auto-inviter",

    -- text
    ["/RELOAD_TEXT"] = "Taktikker opdateret. Brug /reload for UI oversættelse.",

    -- Setting Main
    ["SELECT_LANGUAGE_TITLE"] = "Vælg sprog",
    ["SCALE_SLIDER_TITLE"] = "Addon Skala",
    ["ANIMATIONS_COMBT_TITLE"] = "Tillad animationer i kamp",
    ["CLOSE_WINDOW_TITLE"] = "Luk vindue efter post",
    ["ESC_CLOSE_TITLE"] = "Tillad luk med ESC",
    ["AUTO_OPEN_NOTES_TITLE"] = "Åbn Boss Noter automatisk",

    ["AUTO_INVITE_TITLE"] = "Aktiver Auto-Invite",
    ["TRIGGER_WORD_TITLE"] = "AutoInvite Trigger-ord",

    -- ToolTip settings
    ["LANGUAGE_TOOLTIP_1"] = "Vælg sproget brugt i Mythic Menter.",
    ["LANGUAGE_TOOLTIP_2"] = "Klik for at åbne listen over tilgængelige sprog.",
    ["SCALE_TOOLTIP"] = "Ændrer størrelsen på hele addonet. Træk for at ændre.",
    ["CURRENT_SCALE_TOOLTIP"] = "Nuværende: ",
    ["ANIMATIONS_TOOLTIP"] = "Afspil animationer i kamp.",
    ["CLOSE_WINDOW_TOOLTIP"] = "Luk vinduet efter 'Send til chat' er trykket.",
    ["ESC_CLOSE_TOOLTIP"] = "Luk vindue med ESC.",
    ["AUTO_OPEN_NOTES_TOOLTIP"] = "Åbn Boss Note panelet automatisk\nnår en boss vælges (hvis der findes noter).",

    ["AUTO_INVITE_TOOLTIP"] = "Aktiver Auto-Invite (inviter ved trigger).",
    ["TRIGGER_WORD_TOOLTIP"] = "Trigger-ord for Auto-Invite (f.eks. invite!).",


    -----------------------------------------------
    -- Start Side
    -----------------------------------------------

    -- Text
    ["SELECT_DUNGEON_HINT"] = "Vælg en dungeon i venstre panel for at se bosser og taktikker.",

    -----------------------------------------------
    -- Notes
    -----------------------------------------------

    -- Boss Notes
    ["BOSS_NOTES"] = "Boss Noter",
    ["BOSS_CLOSE_NOTE"] = "Luk note",
    ["ADD_NOTE_TIP"] = "Skriv note og tryk Enter:",

    -- General Notes
    ["GENERAL_NOTES"] = "Generelle noter",
    ["ADD_CATEGORY"] = "Ny kategori",
    ["DEFAULT_CATEGORY"] = "Alle",
    ["CONFIRM_DELETE_NOTE"] = "Er du sikker på, at du vil slette denne note?",
    ["CONFIRM_DELETE_CATEGORY"] = "Er du sikker på, at du vil slette denne kategori og alle dens noter?",


    -----------------------------------------------
    -- Info panel
    -----------------------------------------------

    ["INFO"] = "Infomaton",


    -----------------------------------------------
    -- Socials
    -----------------------------------------------
    ["DISCORD_TOOLTIP"] = "Klik for at få Discord linket.",
    ["JOIN_DISCORD"] = "Deltag i vores Discord!",

    ["GITHUB_TOOLTIP"] = "Klik for at få GitHub linket.",
    ["VISIT_GITHUB"] = "Besøg vores GitHub!",

    ["BUG_TOOLTIP"] = "Klik for at rapportere en fejl.",
    ["REPORT_BUG"] = "Rapportér en fejl!",
    ["BUG_GUIDE"] = "Har du fundet en fejl? Rapportér den via Discord eller GitHub Issues.",

    ["COPY_LINK"] = "Ctrl+C for at kopiere linket.",

    -----------------------------------------------
    -- Update banner
    -----------------------------------------------
    ["UPDATE_AVAILABLE_BANNER"] = "Ny opdatering tilgængelig – Din: %s  Ny: %s  (klik for at åbne)",
}

return L_daDK

Dungeon5 = {
    displayName = "Skyreach",
    realName    = "Skyreach",
    bosses = {
        {
            realName    = "Ranjit",
            displayName = "Ranjit",
            short       = [[
Dodge EVERYTHING and stay away from the platform's edge.
]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "Araknath",
            displayName = "Araknath",
            short       = [[
Soak the three light rays; move out when they become triangles.


Tank. Point boss away from the group & dodge frontal.
]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "Rukhran",
            displayName = "Rukhran",
            short       = [[
1. Killing adds leaves behind an egg; do NOT kill other adds next to these eggs.
2. Run when fixated.
3. Hide behind pillar during the Searing Quills attack.

DPS. please don't stand on each side of det pillar.
]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "High Sage Viryx",
            displayName = "High Sage Viryx",
            short       = [[
1. Interrupt Solar Blast.
2. CC & nuke adds ASAP.
3. When targeted, kite the beam to the edge of the room to save space.
]],
            details     = [[Comming soon
]]
        },
    }
}

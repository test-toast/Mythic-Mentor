Dungeon2 = {
    displayName = "Tazavesh: Streets of Wonder",
    realName    = "Tazavesh, the Veiled Market",
    bosses = {
        {
            realName    = "Zo'phex the Sentinel",
            displayName = "Zo'phex the Sentinel",
            short       = [[
1. Pick up your weapon after being disarmed.
2. Run away if targeted by Interrogation. Destroy the containment cell asap.
]],
            details     = [[
{center}|cFFFF6600ZO'PHEX THE SENTINEL - DETAILED STRATEGY|r{/center}

This is a heavy |cFF00FFFFmovement fight|r with multiple mechanics that test spatial awareness and reaction time.  

__________________________________________________________________________

{center}|cFFFF6600Armed Security|r{/center}

[Boss:Zo'phex] throws out both of his bladed arms, targeting 2 random players with 6yd circles.  
- Standing in these will deal heavy physical damage.  
- The arms remain on the ground temporarily, limiting movement space.  

|cFFFFFF00Strategy:|r  
- Spread slightly to avoid overlapping the circles.  
- You can bait as a group to keep the arena organized.  

__________________________________________________________________________

{center}|cFFFF6600Charged Slash|r{/center}

- Targets a random player with a frontal cone attack.  
- Deals heavy physical damage to all players caught in its path.  

|cFFFFFF00Tips:|r  
- Stay relatively close to the boss so it’s easier to sidestep.  
- Never stand directly in front unless you are the tank.  

__________________________________________________________________________

{center}|cFFFF6600Impound Contraband|r{/center}

Zo’phex pacifies 2 random players, disarming them until they [Important:recover their weapon].  
- Each disarmed player's weapon spawns on the ground nearby; look for the glowing weapon and pick it up quickly.
- Picking it up grants the [Buff:Vigor] buff, increasing Haste by 25%.  

|cFFFFFF00Strategy:|r  
- Disarmed players should quickly locate and [Important:recover their weapon].  
- Tanks/healers may need to cover briefly while DPS are unable to act.  

__________________________________________________________________________

{center}|cFFFF6600Interrogation (Ultimate)|r{/center}

At [Miscellaneous:100 energy], Zo’phex casts [BossAbilities:Interrogation]:  
- Marks a random player, [Debuff:stunning] them in a [Miscellaneous:containment cell] after 4s.  
- Boss fixates on a player, spinning blades in front of him while chasing.  
- If Zo’phex reaches the player, it is usually lethal.  

|cFFFFFF00Strategy:|r  
- The targeted player should immediately run away from the boss.  
- All other players must focus on [Important:destroying the containment cell] to free them.  
- If Targeted by [BossAbilities:Interrogation], use [Important:stun-break abilities] (Icebound Fortitude, Human racial, etc.) to instantly escape.  

__________________________________________________________________________

{center}|cFFFF6600Tank Notes|r{/center}

- Boss melee swings hit hard; use defensives proactively.  
- When Zo’phex casts [BossAbilities:Fully Armed], melee damage is increased by 25% until the next [BossAbilities:Armed Security].  
- Plan cooldowns for this window if possible.

__________________________________________________________________________

|cFFFFFF00Summary Flow:|r  
1. Dodge [BossAbilities:Armed Security] circles and [BossAbilities:Charged Slash] frontals.  
2. Quickly recover your weapon during [BossAbilities:Impound Contraband].  
3. At full energy, free the targeted player during [BossAbilities:Interrogation] before Zo’phex reaches them.  
4. Tanks should stagger cooldowns for [BossAbilities:Fully Armed] windows.  
5. Repeat until Zo’phex is defeated.  

]]
        },
        {
            realName    = "The Grand Menagerie",
            displayName = "The Grand Menagerie",
            short       = [[
Boss-1. Run out when gripped & avoid falling balls.
Boss-2. Absorb anima orbs with the Gluttony debuff. Break shield and interrupt.
Boss-3. Destroy chains. Run when sucked

Extra: Healer Dispel big circles during Boss. (Boss-2).
]],
            details     = ""
        },
        {
            realName    = "Mailroom Mayhem",
            displayName = "Mailroom Mayhem",
            short       = [[
1. Catch falling bottles.
2. Stack in yellow circle.
3. At 100 energy, throw packages in the active delivery column.
]],
            details = ""
        },
        {
            realName    = "Myza's Oasis",
            displayName = "Myza's Oasis",
            short       = [[
1. Use instrument's extra action button to hit notes.
2. Adds: Interrupt shout & CC mobs casting Surpression.
3. Zo'gron spawns: Move out of the Crowd Control frontal attack. Move out with circles. Break shield.
]],
            details = ""
        },
        {
            realName    = "So'azmi",
            displayName = "So'azmi",
            short       = [[
Teleport inside the circle attack using the shapes. Two interrupts are needed to stop Double Technique.
]],
            details = ""
        },
        
    }
}

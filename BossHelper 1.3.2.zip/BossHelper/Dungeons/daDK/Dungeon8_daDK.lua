Dungeon8 = {
    displayName = "Algeth'ar Academy",
    realName    = "Algeth'ar Academy",
    bosses = {
        {
            realName    = "Vexamus",
            displayName = "Vexamus",
            short       = [[
1. Soak orbs (1 each).
2. Move out with circle.

Tank. Point frontal away from group.
]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "Overgrown Ancient",
            displayName = "Overgrown Ancient",
            short       = [[
1. Spawn Germinate adds close together; nuke ASAP.
2. Clense debuffs in green circle.
3. Interrupt Ancient Branch add.
]],
            details     = [[Comming soon
]]
        },
                {
            realName    = "Crawth",
            displayName = "Crawth",
            short       = [[
1. Avoid frontal, spread circles, don't cast during screech.
Wind Phase: grab orbs & dodge evil tornadoes.
Fire Phase: fire = bad.
]],
            details     = [[Comming soon
]]
        },
                {
            realName    = "Echo of Doragosa",
            displayName = "Echo of Doragosa",
            short       = [[
1. All attacks apply a debuff. Move out right before you get 3 stacks.
2. Avoid orbs & run when sucked.

Tank. Point frontal away from group.
]],
            details     = [[Comming soon
]]
        },
    }
}

Dungeon2 = {
    displayName = "Magister's Terrace",
    realName    = "Magisters' Terrace",
    bosses = {
        {
            realName    = "Arcanotron Custos",
            displayName = "Arcanotron Custos",
            short       = [[
1. Avoid puddles, and soak orbs when they come (ideally not near the boss).

Healer. Dispel debuffs asap.
Tank. Boss creates puddles. Kite near walls to managed space.
]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "Seranel Sunlash",
            displayName = "Seranel Sunlash",
            short       = [[
1. 3 players get marked. Step in purple zone to remove - but stagger this!
2. Go into the purple zone when boss cast Vow of Silence.
3. Missles = bad.


]],
            details     = [[Comming soon
]]
        },
        {
            realName    = "Gemellus",
            displayName = "Gemellus",
            short       = [[
1. Move out when targeted by Cosmic Sting.
2. When blue arrow appears, follow it & touch the clone
3. Run when sucked.
]],
            details = [[Comming soon
]]
        },
        {
            realName    = "Degentrius",
            displayName = "Degentrius",
            short       = [[
1. The room is split in to. You need at least one player on one side.
2. catch all balls.

Tank/healer move out with debuff for healer dispel.
]],
            details = [[Comming soon
]]
        },
        
    }
}
